'use strict';
// Fictional training data. No external API calls or persistent storage.
const policies = {
  'AUTO-10025': {name:'Priya Sharma',vehicle:'2023 Toyota RAV4',effective:'2026-01-01',expiry:'2026-12-31',status:'Active',coverage:'Collision, Comprehensive, Liability'},
  'AUTO-20045': {name:'Rahul Mehta',vehicle:'2022 Honda Civic',effective:'2025-01-01',expiry:'2025-12-31',status:'Expired',coverage:'Liability'},
  'AUTO-30015': {name:'Anita Patel',vehicle:'2024 Mazda CX-5',effective:'2026-01-01',expiry:'2026-12-31',status:'Cancelled',coverage:'Collision, Liability'}
};
const $ = id => document.getElementById(id);
let lookedUp = false;
function reset(){lookedUp=false;$('policyDetails').hidden=true;$('checks').textContent='Search a policy to run validation.';$('register').disabled=true;$('result').textContent='';}
function validate(){if(!lookedUp)return;const p=policies[$('policy').value],date=$('lossDate').value,desc=$('description').value.trim();const within=!!date&&date>=p.effective&&date<=p.expiry;const active=p.status==='Active';const complete=desc.length>0;const checks=[['Loss date within policy period',within],['Policy status active',active],['Loss description provided',complete]];$('checks').replaceChildren();checks.forEach(([label,ok])=>{const row=document.createElement('p');row.className=ok?'ok':'warn';row.textContent=(ok?'✓ ':'⚠ ')+label+': '+(ok?'Yes':'No');$('checks').append(row)});if(!within||!active){const note=document.createElement('p');note.className='warn';note.textContent='Review required: status or date discrepancy. This demo does not make a coverage determination.';$('checks').append(note)}$('register').disabled=!(within&&active&&complete);$('result').textContent='';}
$('search').addEventListener('click',()=>{const p=policies[$('policy').value];lookedUp=true;$('policyDetails').replaceChildren();Object.entries({Insured:p.name,Vehicle:p.vehicle,'Policy status':p.status,'Effective date':p.effective,'Expiration date':p.expiry,Coverages:p.coverage}).forEach(([k,v])=>{const row=document.createElement('p');const strong=document.createElement('strong');strong.textContent=k+': ';row.append(strong,document.createTextNode(v));$('policyDetails').append(row)});$('policyDetails').hidden=false;validate()});
$('policy').addEventListener('change',reset);$('lossDate').addEventListener('change',validate);$('description').addEventListener('input',validate);
$('register').addEventListener('click',()=>{if(!$('register').disabled)$('result').textContent='✓ Demo claim registered: DEMO-FNOL-001 (no actual claim created).'});
function tab(which){$('workflow').hidden=which!=='workflow';$('artifacts').hidden=which!=='artifacts';$('workflowTab').classList.toggle('selected',which==='workflow');$('artifactsTab').classList.toggle('selected',which==='artifacts')}
$('workflowTab').addEventListener('click',()=>tab('workflow'));$('artifactsTab').addEventListener('click',()=>tab('artifacts'));
