# FNOL Business Analyst Training Lab

An interactive **Guidewire ClaimCenter-style** First Notice of Loss (FNOL) business-analysis portfolio project. Built with plain HTML, CSS, and JavaScript; no installation required.

> **Disclaimer:** Fictional training simulation only. Not affiliated with Intact Insurance or Guidewire. It is not a real ClaimCenter implementation, integration, or proof of professional project delivery. All policyholder details are invented.

## Live demo

After enabling GitHub Pages, add your URL here: `https://YOUR-USERNAME.github.io/fnol-ba-demo/`

## Run locally

Download the repository and open `index.html` in a web browser. No server, credentials, or API keys needed.

## Try these scenarios

1. Select `AUTO-10025`, click **Search policy**, use `2026-10-20`, and register a **simulated** claim.
2. Select `AUTO-20045` to inspect an expired-policy exception.
3. Select `AUTO-30015` to inspect a cancelled-policy exception.
4. Clear the loss description to see mandatory field validation.
5. Open **BA Artifacts** for requirements, scope, acceptance criteria, data catalogue, traceability, and NFR examples.

## BA case study

**Problem/opportunity:** Manual policy re-entry may increase FNOL time and transcription errors.

**Proposed scope:** Policy lookup, field population, basic validation, and exception visibility. Billing, settlement, and premium rating are excluded.

**Business context:** Adjuster → ClaimCenter-style FNOL interface ↔ simulated Policy Administration data. This project mocks the returned policy data in `script.js`; it does not use a live integration.

**Business rule examples:** Flag dates outside policy effective period; flag cancelled or expired status; require a loss description. The demo blocks the *simulated* register action for these exceptions for teaching purposes. Actual insurer workflows may allow registration pending coverage review; policy status alone is not a coverage determination.

**Traceability:** BR-001 → FR-001 → US-001 → AC-1, AC-2, AC-3.

**Possible future improvements:** Wireframes, as-is/to-be BPMN diagrams, formal requirements traceability matrix, test scenarios, and a mocked REST endpoint.

## Files

- `index.html` — UI and sample BA deliverables
- `styles.css` — responsive styling
- `script.js` — fictional policy data and validation logic

## Suggested interview description

> I created a standalone FNOL business-analysis training demo to show how policy retrieval, validation, exception handling, user stories, acceptance criteria, and requirements traceability fit together. It uses fictional data and does not connect to a production Guidewire system.

## License

MIT. See `LICENSE`.
